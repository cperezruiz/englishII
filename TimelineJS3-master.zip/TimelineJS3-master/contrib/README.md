# Community Contributions

## Disclaimer

Files in this directory have been contributed by the community. No review, testing, or verification for anything here has been done by the Knight Lab. Please use with caution and at your own risk.

## Organization

Contributions are organized into directories according to the submitter's GitHub username.

## Contributing

If you have made something for TimelineJS that you thing would be useful to the community, please submit it via pull request in the GitHub repository: https://github.com/NUKnightLab/TimelineJS3
