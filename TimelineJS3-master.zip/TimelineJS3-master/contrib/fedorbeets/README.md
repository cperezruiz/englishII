A version of timeline.py from @iamamoose that will also convert era's

See: https://github.com/NUKnightLab/TimelineJS3/issues/398
